# TransLingua
AI-Powered Multi-Language Translator
designed for seamless text and speech translation across various languages.It ensures accurate and context-aware translations.
